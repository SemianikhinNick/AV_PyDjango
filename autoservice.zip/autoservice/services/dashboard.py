from django.shortcuts import render
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Count
from datetime import date
from .models import Appointment, Service

@staff_member_required
def dashboard(request):
    status_stats = {
        'new': Appointment.objects.filter(status='new').count(),
        'in_progress': Appointment.objects.filter(status='in_progress').count(),
        'confirmed': Appointment.objects.filter(status='confirmed').count(),
        'completed': Appointment.objects.filter(status='completed').count(),
        'cancelled': Appointment.objects.filter(status='cancelled').count(),
    }
    
    # Последние 10 заявок
    recent_appointments = Appointment.objects.all()[:10]
    
    # Статистика по услугам
    service_stats = []
    for service in Service.objects.all():
        count = Appointment.objects.filter(service=service).count()
        if count > 0:
            service_stats.append({
                'name': service.name,
                'count': count
            })
    
    # Заявки за сегодня
    today_appointments = Appointment.objects.filter(created_at__date=date.today())
    
    context = {
        'status_stats': status_stats,
        'recent_appointments': recent_appointments,
        'service_stats': service_stats,
        'today_appointments': today_appointments,
        'total_appointments': Appointment.objects.count(),
    }
    
    return render(request, 'services/dashboard.html', context)