from django.urls import path
from . import views
from . import dashboard 

urlpatterns = [
    path('', views.index, name='index'),
    path('services/', views.services, name='services'),
    path('contacts/', views.contacts, name='contacts'),
    path('appointment/', views.make_appointment, name='appointment'),
    path('dashboard/', dashboard.dashboard, name='dashboard'),
]