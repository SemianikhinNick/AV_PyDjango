from django.contrib import admin
from .models import Service, Advantage, Review, Contact, SocialLink, Appointment

@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'price', 'is_popular', 'order']
    list_filter = ['category', 'is_popular']
    search_fields = ['name', 'description']
    list_editable = ['price', 'is_popular', 'order']

@admin.register(Advantage)
class AdvantageAdmin(admin.ModelAdmin):
    list_display = ['title', 'order']
    list_editable = ['order']

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ['author_name', 'author_car', 'rating', 'date', 'is_published']
    list_filter = ['rating', 'is_published', 'date']
    list_editable = ['is_published']

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ['phone', 'email', 'address']

@admin.register(SocialLink)
class SocialLinkAdmin(admin.ModelAdmin):
    list_display = ['platform', 'url', 'order']
    list_editable = ['order']

@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ['id', 'client_name', 'client_phone', 'service_name', 'appointment_date', 'status', 'created_at']
    list_filter = ['status', 'created_at', 'appointment_date']
    search_fields = ['client_name', 'client_phone', 'client_car', 'service_name', 'comments']
    list_editable = ['status']
    readonly_fields = ['created_at', 'updated_at']
    date_hierarchy = 'created_at'
    
    fieldsets = [
        ('Информация о клиенте', {
            'fields': ['client_name', 'client_phone', 'client_car']
        }),
        ('Информация об услуге', {
            'fields': ['service', 'service_name', 'appointment_date', 'comments']
        }),
        ('Статус и обработка', {
            'fields': ['status', 'processed_by', 'notes']
        }),
        ('Системная информация', {
            'fields': ['created_at', 'updated_at'],
            'classes': ['collapse']
        }),
    ]
    
    actions = ['mark_as_in_progress', 'mark_as_confirmed', 'mark_as_completed', 'mark_as_cancelled']
    
    def mark_as_in_progress(self, request, queryset):
        queryset.update(status='in_progress')
    mark_as_in_progress.short_description = "Отметить как 'В обработке'"
    
    def mark_as_confirmed(self, request, queryset):
        queryset.update(status='confirmed')
    mark_as_confirmed.short_description = "Отметить как 'Подтверждена'"
    
    def mark_as_completed(self, request, queryset):
        queryset.update(status='completed')
    mark_as_completed.short_description = "Отметить как 'Выполнена'"
    
    def mark_as_cancelled(self, request, queryset):
        queryset.update(status='cancelled')
    mark_as_cancelled.short_description = "Отметить как 'Отменена'"
    
    def save_model(self, request, obj, form, change):
        if not obj.pk:
            pass
        if 'status' in form.changed_data and not obj.processed_by:
            obj.processed_by = request.user
        super().save_model(request, obj, form, change)