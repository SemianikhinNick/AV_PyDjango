from django.db import models

class Service(models.Model):
    CATEGORY_CHOICES = [
        ('engine', 'Двигатель'),
        ('transmission', 'Трансмиссия'),
        ('suspension', 'Подвеска'),
        ('brakes', 'Тормозная система'),
        ('electrics', 'Электрика'),
        ('diagnostics', 'Диагностика'),
        ('maintenance', 'ТО'),
    ]

    name = models.CharField('Название услуги', max_length=200)
    category = models.CharField('Категория', max_length=20, choices=CATEGORY_CHOICES)
    description = models.TextField('Описание')
    price = models.DecimalField('Цена', max_digits=10, decimal_places=2)  # Исправлено
    is_popular = models.BooleanField('Популярная', default=False)
    icon = models.CharField('Иконка (Font Awesome)', max_length=50, 
                           help_text='Например: fa-oil-can, fa-car-battery', blank=True)  # Исправлено
    order = models.PositiveIntegerField('Порядок', default=0)  # Исправлено

    class Meta:
        ordering = ['order', 'name']
        verbose_name = 'Услуга'
        verbose_name_plural = 'Услуги'

    def __str__(self):
        return self.name


class Advantage(models.Model):
    title = models.CharField('Заголовок', max_length=200)
    description = models.TextField('Описание')
    icon = models.CharField('Иконка', max_length=50)
    order = models.PositiveIntegerField('Порядок', default=0)  # Исправлено

    class Meta:
        ordering = ['order']
        verbose_name = 'Преимущество'
        verbose_name_plural = 'Преимущества'

    def __str__(self):
        return self.title


class Review(models.Model):
    author_name = models.CharField('Имя клиента', max_length=100)
    author_car = models.CharField('Автомобиль', max_length=200, blank=True)
    text = models.TextField('Текст отзыва')

    rating = models.PositiveSmallIntegerField(
        'Оценка',
        default=5,
        choices=[(i, i) for i in range(1, 6)]
    )

    date = models.DateField('Дата', auto_now_add=True)
    is_published = models.BooleanField('Опубликован', default=True)

    class Meta:
        ordering = ['-date']
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'

    def __str__(self):
        return f'{self.author_name} - {self.date}'


class Contact(models.Model):
    phone = models.CharField('Телефон', max_length=20)
    email = models.EmailField('Email')
    address = models.CharField('Адрес', max_length=300)  # Увеличено
    work_hours = models.CharField('Часы работы', max_length=200,
                                  default='Пн-Пт: 9:00-20:00, Сб-Вс: 10:00-18:00')
    map_link = models.URLField('Ссылка на карту', blank=True)

    class Meta:
        verbose_name = 'Контакт'
        verbose_name_plural = 'Контакты'

    def __str__(self):
        return self.phone


class SocialLink(models.Model):
    platform = models.CharField('Платформа', max_length=50)
    icon = models.CharField('Иконка', max_length=50,
                            help_text='Например: fa-telegram, fa-whatsapp')
    url = models.URLField('Ссылка')
    order = models.PositiveIntegerField('Порядок', default=0)  # Исправлено

    class Meta:
        ordering = ['order']
        verbose_name = 'Социальная сеть'
        verbose_name_plural = 'Социальные сети'

    def __str__(self):
        return self.platform


class Appointment(models.Model):
    """
    Модель для отслеживания заявок на услуги
    """
    STATUS_CHOICES = [
        ('new', 'Новая'),
        ('in_progress', 'В обработке'),
        ('confirmed', 'Подтверждена'),
        ('completed', 'Выполнена'),
        ('cancelled', 'Отменена'),
    ]
    
    service = models.ForeignKey(
        Service, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        verbose_name='Услуга',
        related_name='appointments'
    )
    service_name = models.CharField('Название услуги', max_length=200, blank=True)
    client_name = models.CharField('Имя клиента', max_length=100)
    client_phone = models.CharField('Телефон', max_length=20, db_index=True)  # Добавлен индекс
    client_car = models.CharField('Автомобиль', max_length=200, blank=True)
    appointment_date = models.DateField('Желаемая дата', null=True, blank=True)
    comments = models.TextField('Комментарий', blank=True)
    
    status = models.CharField(
        'Статус', 
        max_length=20, 
        choices=STATUS_CHOICES, 
        default='new'
    )
    
    created_at = models.DateTimeField('Дата создания', auto_now_add=True)
    updated_at = models.DateTimeField('Дата обновления', auto_now=True)
    processed_by = models.ForeignKey(
        'auth.User',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name='Обработал',
        related_name='processed_appointments'
    )
    
    notes = models.TextField('Заметки', blank=True, help_text='Внутренние заметки для сотрудников')
    
    # Новые поля для защиты от дубликатов
    request_hash = models.CharField('Хеш запроса', max_length=64, blank=True, editable=False, db_index=True)
    ip_address = models.GenericIPAddressField('IP адрес', blank=True, null=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name = 'Заявка'
        verbose_name_plural = 'Заявки'
        constraints = [
            models.UniqueConstraint(
                fields=['client_phone', 'created_at'],
                name='unique_phone_per_minute'
            )
        ]
    
    def __str__(self):
        return f'Заявка #{self.id} - {self.client_name} - {self.created_at.strftime("%d.%m.%Y")}'
    
    def save(self, *args, **kwargs):
        if self.service and not self.service_name:
            self.service_name = self.service.name

        import hashlib
        import json
        from datetime import datetime
        
        unique_string = f"{self.client_name}{self.client_phone}{self.comments}{datetime.now().strftime('%Y%m%d%H%M')}"
        self.request_hash = hashlib.sha256(unique_string.encode()).hexdigest()
        
        super().save(*args, **kwargs)