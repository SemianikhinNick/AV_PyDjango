from django import forms
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone
from datetime import timedelta
from .models import Service, Appointment

class ContactForm(forms.Form):
    name = forms.CharField(
        max_length=100,
        label='Ваше имя',
        widget=forms.TextInput(attrs={
            'class': 'w-full px-4 py-4 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-blue-500 text-white transition-all duration-300',
            'placeholder': 'Иван Иванов'
        })
    )
    
    phone = forms.CharField(
        max_length=20,
        label='Телефон',
        widget=forms.TextInput(attrs={
            'class': 'w-full px-4 py-4 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-blue-500 text-white transition-all duration-300',
            'placeholder': '+375 (33) 123-45-67'
        })
    )
    
    email = forms.EmailField(
        required=False,
        label='Email',
        widget=forms.EmailInput(attrs={
            'class': 'w-full px-4 py-4 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-blue-500 text-white transition-all duration-300',
            'placeholder': 'ivan@example.com'
        })
    )
    
    appointment_date = forms.DateField(
        required=False,
        label='Желаемая дата',
        widget=forms.DateInput(attrs={
            'class': 'w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-blue-500 text-white transition-colors',
            'type': 'date',
            'min': '{{ now|date:"Y-m-d" }}'
        })
    )
    
    message = forms.CharField(
        label='Сообщение',
        widget=forms.Textarea(attrs={
            'class': 'w-full px-4 py-4 bg-white/5 border border-white/10 rounded-xl focus:outline-none focus:border-blue-500 text-white transition-all duration-300',
            'placeholder': 'Опишите вашу проблему или вопрос...',
            'rows': 5
        })
    )
    
    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        phone_digits = ''.join(filter(str.isdigit, phone))
        if len(phone_digits) < 9:
            raise forms.ValidationError('Введите корректный номер телефона')
        return phone
    
    def clean(self):
        cleaned_data = super().clean()
        phone = cleaned_data.get('phone')
        
        if phone:
            phone_digits = ''.join(filter(str.isdigit, phone))

            five_minutes_ago = timezone.now() - timedelta(minutes=5)
        
            recent_appointments = Appointment.objects.filter(
                client_phone__icontains=phone_digits[-9:], 
                created_at__gte=five_minutes_ago
            )
            
            if recent_appointments.exists():
                self.add_error('phone', 'Заявка с таким номером уже отправлена. Пожалуйста, подождите 5 минут.')
        
        return cleaned_data
    
    def save_contact(self, request=None):

        phone = self.cleaned_data['phone']
        phone_digits = ''.join(filter(str.isdigit, phone))

        five_minutes_ago = timezone.now() - timedelta(minutes=5)
        if Appointment.objects.filter(
            client_phone__icontains=phone_digits[-9:],
            created_at__gte=five_minutes_ago
        ).exists():
            raise Exception('Заявка с таким телефоном уже была отправлена недавно')
        
        appointment_date = self.cleaned_data.get('appointment_date')
        
        comments = f"Email: {self.cleaned_data.get('email', 'Не указан')}"
        if appointment_date:
            comments += f"\nЖелаемая дата: {appointment_date.strftime('%d.%m.%Y')}"
        comments += f"\n\nСообщение: {self.cleaned_data['message']}"

        ip_address = None
        if request and hasattr(request, 'META'):
            ip_address = request.META.get('REMOTE_ADDR')
        
        appointment = Appointment.objects.create(
            service=None,
            service_name='Обратная связь (контакты)',
            client_name=self.cleaned_data['name'],
            client_phone=phone,
            client_car='',
            appointment_date=appointment_date,
            comments=comments,
            status='new',
        )
        
        return appointment
    
    def send_email(self, request=None):
        appointment = self.save_contact(request)
        
        name = self.cleaned_data['name']
        phone = self.cleaned_data['phone']
        email = self.cleaned_data.get('email', '')
        message = self.cleaned_data['message']
        appointment_date = self.cleaned_data.get('appointment_date')
        
        date_str = appointment_date.strftime('%d.%m.%Y') if appointment_date else 'Не указана'
        
        subject = f'Новое обращение #{appointment.id} от {name}'
        body = f"""
        НОВОЕ ОБРАЩЕНИЕ #{appointment.id}
        
        Имя: {name}
        Телефон: {phone}
        Email: {email if email else 'не указан'}
        Желаемая дата: {date_str}
        
        Сообщение:
        {message}
        
        Ссылка в админке: http://127.0.0.1:8000/admin/services/appointment/{appointment.id}/change/
        """
        
        # HTML-версия письма (без изменений)
        html_message = f"""
        <html>
        <head>
            <style>
                body {{ font-family: 'Arial', sans-serif; background: #f4f4f4; padding: 20px; }}
                .container {{ max-width: 600px; margin: 0 auto; background: white; border-radius: 20px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.1); }}
                .header {{ background: linear-gradient(135deg, #3B82F6, #8B5CF6); padding: 30px; text-align: center; }}
                .header h1 {{ margin: 0; color: white; font-size: 28px; }}
                .content {{ padding: 30px; }}
                .field {{ margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-radius: 10px; border-left: 4px solid #3B82F6; }}
                .label {{ font-weight: bold; color: #666; font-size: 12px; text-transform: uppercase; margin-bottom: 5px; }}
                .value {{ color: #333; font-size: 16px; }}
                .date-field {{ border-left-color: #8B5CF6; }}
                .status-new {{ display: inline-block; background: #FEF3C7; color: #92400E; padding: 5px 15px; border-radius: 20px; font-size: 14px; }}
                .button {{ display: inline-block; background: linear-gradient(135deg, #3B82F6, #8B5CF6); color: white; text-decoration: none; padding: 12px 30px; border-radius: 30px; margin-top: 20px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🆕 Новое обращение #{appointment.id}</h1>
                </div>
                <div class="content">
                    <div class="field">
                        <div class="label">Имя клиента</div>
                        <div class="value">{name}</div>
                    </div>
                    <div class="field">
                        <div class="label">Телефон</div>
                        <div class="value">{phone}</div>
                    </div>
                    <div class="field">
                        <div class="label">Email</div>
                        <div class="value">{email if email else 'Не указан'}</div>
                    </div>
                    <div class="field date-field">
                        <div class="label">Желаемая дата</div>
                        <div class="value">{date_str}</div>
                    </div>
                    <div class="field">
                        <div class="label">Сообщение</div>
                        <div class="value">{message}</div>
                    </div>
                    <div class="field">
                        <div class="label">Статус</div>
                        <div><span class="status-new">Новая заявка</span></div>
                    </div>
                    <div style="text-align: center;">
                        <a href="http://127.0.0.1:8000/admin/services/appointment/{appointment.id}/change/" class="button">
                            Открыть в админке
                        </a>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
        
        send_mail(
            subject,
            body,
            settings.DEFAULT_FROM_EMAIL,
            [settings.CONTACT_EMAIL],
            fail_silently=False,
            html_message=html_message
        )


class AppointmentForm(forms.Form):
    service_id = forms.IntegerField(widget=forms.HiddenInput(), required=False)
    client_name = forms.CharField(
        max_length=100,
        label='Ваше имя',
        widget=forms.TextInput(attrs={
            'class': 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500',
            'placeholder': 'Иван Иванов'
        })
    )
    client_phone = forms.CharField(
        max_length=20,
        label='Телефон',
        widget=forms.TextInput(attrs={
            'class': 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500',
            'placeholder': '+7 (900) 123-45-67'
        })
    )
    client_car = forms.CharField(
        max_length=200,
        required=False,
        label='Автомобиль',
        widget=forms.TextInput(attrs={
            'class': 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500',
            'placeholder': 'Марка и модель'
        })
    )
    appointment_date = forms.DateField(
        required=False,
        label='Желаемая дата',
        widget=forms.DateInput(attrs={
            'class': 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500',
            'type': 'date'
        })
    )
    comments = forms.CharField(
        required=False,
        label='Комментарий',
        widget=forms.Textarea(attrs={
            'class': 'w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500',
            'rows': 3,
            'placeholder': 'Дополнительная информация'
        })
    )
    
    def clean_client_phone(self):
        phone = self.cleaned_data.get('client_phone')
        phone_digits = ''.join(filter(str.isdigit, phone))
        if len(phone_digits) < 9:
            raise forms.ValidationError('Введите корректный номер телефона')
        return phone
    
    def clean(self):
        cleaned_data = super().clean()
        phone = cleaned_data.get('client_phone')
        
        if phone:
            phone_digits = ''.join(filter(str.isdigit, phone))
            five_minutes_ago = timezone.now() - timedelta(minutes=5)
            
            recent_appointments = Appointment.objects.filter(
                client_phone__icontains=phone_digits[-9:],
                created_at__gte=five_minutes_ago
            )
            
            if recent_appointments.exists():
                self.add_error('client_phone', 'Заявка с таким номером уже отправлена. Пожалуйста, подождите 5 минут.')
        
        return cleaned_data
    
    def save_appointment(self, request=None):
        phone = self.cleaned_data['client_phone']
        phone_digits = ''.join(filter(str.isdigit, phone))
        
        five_minutes_ago = timezone.now() - timedelta(minutes=5)
        if Appointment.objects.filter(
            client_phone__icontains=phone_digits[-9:],
            created_at__gte=five_minutes_ago
        ).exists():
            raise Exception('Заявка с таким телефоном уже была отправлена недавно')
        
        service_id = self.cleaned_data.get('service_id')
        service = None
        service_name = "Не указана"
        
        if service_id:
            try:
                service = Service.objects.get(id=service_id)
                service_name = service.name
            except Service.DoesNotExist:
                pass

        appointment = Appointment.objects.create(
            service=service,
            service_name=service_name,
            client_name=self.cleaned_data['client_name'],
            client_phone=phone,
            client_car=self.cleaned_data.get('client_car', ''),
            appointment_date=self.cleaned_data.get('appointment_date'),
            comments=self.cleaned_data.get('comments', ''),
            status='new'
        )
        
        return appointment
    
    def send_appointment_email(self, request=None):
        """
        Отправка email с данными записи
        """
        appointment = self.save_appointment(request)
        subject = f'Новая заявка #{appointment.id} от {appointment.client_name}'

        html_message = f"""
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; }}
                .appointment {{ 
                    background: #f0f9ff; 
                    padding: 20px; 
                    border-radius: 10px;
                    border-left: 4px solid #3b82f6;
                }}
                .field {{ margin-bottom: 10px; }}
                .label {{ font-weight: bold; color: #4b5563; }}
                .value {{ color: #111827; }}
                .status-new {{ 
                    background: #fef3c7; 
                    color: #92400e; 
                    padding: 5px 10px; 
                    border-radius: 9999px;
                    display: inline-block;
                }}
            </style>
        </head>
        <body>
            <h2>🆕 Новая заявка #{appointment.id}</h2>
            <div class="appointment">
                <div class="field">
                    <span class="label">Услуга:</span>
                    <span class="value">{appointment.service_name}</span>
                </div>
                <div class="field">
                    <span class="label">Клиент:</span>
                    <span class="value">{appointment.client_name}</span>
                </div>
                <div class="field">
                    <span class="label">Телефон:</span>
                    <span class="value">{appointment.client_phone}</span>
                </div>
                <div class="field">
                    <span class="label">Автомобиль:</span>
                    <span class="value">{appointment.client_car or 'Не указан'}</span>
                </div>
                <div class="field">
                    <span class="label">Желаемая дата:</span>
                    <span class="value">{appointment.appointment_date or 'Не указана'}</span>
                </div>
                <div class="field">
                    <span class="label">Комментарий:</span>
                    <span class="value">{appointment.comments or 'Нет'}</span>
                </div>
                <div class="field">
                    <span class="label">Статус:</span>
                    <span class="status-new">Новая</span>
                </div>
            </div>
            <p>
                <a href="http://127.0.0.1:8000/admin/services/appointment/{appointment.id}/change/" 
                   style="background: #3b82f6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
                    Открыть в админке
                </a>
            </p>
        </body>
        </html>
        """
        
        send_mail(
            subject,
            f"Новая заявка #{appointment.id}. Подробности в админке: http://127.0.0.1:8000/admin/services/appointment/{appointment.id}/",
            settings.DEFAULT_FROM_EMAIL,
            [settings.CONTACT_EMAIL],
            fail_silently=False,
            html_message=html_message
        )