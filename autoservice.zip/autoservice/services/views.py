from django.shortcuts import render, redirect
from django.contrib import messages
from django.http import JsonResponse
from .models import Service, Advantage, Review, Contact, SocialLink, Appointment
from .forms import ContactForm, AppointmentForm  # Оба класса импортируем

def index(request):
    popular_services = Service.objects.filter(is_popular=True)[:6]
    advantages = Advantage.objects.all()
    reviews = Review.objects.filter(is_published=True)[:6]
    
    context = {
        'popular_services': popular_services,
        'advantages': advantages,
        'reviews': reviews,
    }
    return render(request, 'services/index.html', context)

def services(request):
    services_list = Service.objects.all()
    context = {
        'services': services_list,
    }
    return render(request, 'services/services.html', context)

def contacts(request):
    contacts_info = Contact.objects.first()
    social_links = SocialLink.objects.all()
    
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            # Сохраняем в БД и отправляем email
            form.send_email()
            
            # Добавляем сообщение об успехе
            messages.success(request, 'Спасибо за обращение! Мы свяжемся с вами в ближайшее время.')
            
            # Для AJAX запросов
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'message': 'Спасибо за обращение! Мы свяжемся с вами.'
                })
            
            return redirect('contacts')
        else:
            # Если форма невалидна, показываем ошибки
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f'{field}: {error}')
            
            # Для AJAX запросов
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': False,
                    'errors': form.errors
                }, status=400)
    else:
        form = ContactForm()
    
    context = {
        'contacts': contacts_info,
        'social_links': social_links,
        'form': form,
    }
    
    return render(request, 'services/contacts.html', context)

def make_appointment(request):
    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            # Сохраняем в БД и отправляем email
            form.send_appointment_email()
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True,
                    'message': 'Запись успешно отправлена! Мы свяжемся с вами.'
                })
            else:
                messages.success(request, 'Запись успешно отправлена! Мы свяжемся с вами.')
                return redirect('services')
        else:
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': False,
                    'errors': form.errors
                }, status=400)
    
    return redirect('services')