document.addEventListener('DOMContentLoaded', () => {
    initSmoothScroll();
    initScrollAnimations();
    initPhoneMask();
    initHoverEffects();
    initLazyLoading();
});

function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', (e) => {
            e.preventDefault();
            const target = document.querySelector(anchor.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                // Опционально: убираем наблюдение после появления
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });

    document.querySelectorAll('.section-fade-in').forEach(el => {
        observer.observe(el);
    });
}

function initPhoneMask() {
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    
    phoneInputs.forEach(input => {
        input.addEventListener('input', (e) => {
            let value = e.target.value.replace(/\D/g, '');
            
            if (value.length > 0) {
                if (value.startsWith('375')) {
                    if (value.length <= 3) {
                        value = `+${value}`;
                    } else if (value.length <= 5) {
                        value = `+${value.substring(0, 3)} (${value.substring(3)}`;
                    } else if (value.length <= 8) {
                        value = `+${value.substring(0, 3)} (${value.substring(3, 5)}) ${value.substring(5)}`;
                    } else {
                        value = `+${value.substring(0, 3)} (${value.substring(3, 5)}) ${value.substring(5, 8)}-${value.substring(8, 10)}-${value.substring(10, 12)}`;
                    }
                } else {
                    value = '+' + value;
                }
                
                e.target.value = value;
            }
        });

        input.addEventListener('focus', () => {
            input.parentElement?.classList.add('focused');
        });

        input.addEventListener('blur', () => {
            input.parentElement?.classList.remove('focused');
        });
    });
}

function initHoverEffects() {
    const cards = document.querySelectorAll('.hover-lift');
    
    cards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            const rotateX = (y - centerY) / 20;
            const rotateY = (centerX - x) / 20;
            
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-4px)`;
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateY(0)';
        });
    });
}

function initLazyLoading() {
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    const src = img.dataset.src;
                    
                    if (src) {
                        img.src = src;
                        img.classList.add('fade-in');
                        imageObserver.unobserve(img);
                    }
                }
            });
        });

        document.querySelectorAll('img[data-src]').forEach(img => {
            imageObserver.observe(img);
        });
    }
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `fixed bottom-6 right-6 px-6 py-4 rounded-2xl shadow-2xl transform transition-all duration-500 translate-y-0 opacity-100 z-50 ${
        type === 'success' ? 'bg-black text-white' : 'bg-red-500 text-white'
    }`;
    notification.innerHTML = `
        <div class="flex items-center space-x-3">
            <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
            <span class="text-sm font-medium">${message}</span>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.transform = 'translateY(100%)';
        notification.style.opacity = '0';
        setTimeout(() => notification.remove(), 500);
    }, 3000);
}

// Валидация форм
function validateForm(form) {
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.classList.add('border-red-500');
            isValid = false;
            
            const tooltip = document.createElement('div');
            tooltip.className = 'absolute -top-8 left-0 bg-red-500 text-white text-xs px-2 py-1 rounded';
            tooltip.textContent = 'Обязательное поле';
            
            const parent = field.parentElement;
            parent.style.position = 'relative';
            parent.appendChild(tooltip);
            
            setTimeout(() => tooltip.remove(), 2000);
        } else {
            field.classList.remove('border-red-500');
        }
    });
    
    return isValid;
}

// Отправка формы через AJAX
async function submitFormAjax(form, url) {
    const formData = new FormData(form);
    
    try {
        const response = await fetch(url, {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(data.message, 'success');
            form.reset();
        } else {
            showNotification('Ошибка при отправке', 'error');
        }
        
        return data;
    } catch (error) {
        showNotification('Ошибка соединения', 'error');
        throw error;
    }
}